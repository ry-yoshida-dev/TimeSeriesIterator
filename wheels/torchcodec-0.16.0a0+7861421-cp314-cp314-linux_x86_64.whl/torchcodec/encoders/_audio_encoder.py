import io
from pathlib import Path

import torch
from torch import Tensor

from torchcodec._internally_replaced_utils import load_core_libraries
from torchcodec.encoders._multi_stream_encoder import Encoder


class AudioEncoder:
    """A single-stream audio encoder.

    .. note::
        This is a convenience class for simple, one-shot audio encoding. For
        multi-stream encoding (e.g. video + audio), incremental encoding, or
        encoding multiple audio streams, use
        :class:`~torchcodec.encoders.Encoder` instead. See
        :ref:`sphx_glr_generated_examples_encoding_multi_stream_encoding.py` for
        a tutorial.

    Args:
        samples (``torch.Tensor``): The samples to encode. This must be a 2D
            tensor of shape ``(num_channels, num_samples)``, or a 1D tensor in
            which case ``num_channels = 1`` is assumed. Values must be float
            values in ``[-1, 1]``.
        sample_rate (int): The sample rate of the **input** ``samples``. The
            sample rate of the encoded output can be specified using the
            encoding methods (``to_file``, etc.).
    """

    def __init__(self, samples: Tensor, *, sample_rate: int):
        torch._C._log_api_usage_once("torchcodec.encoders.AudioEncoder")
        load_core_libraries()
        # Some of these checks are also done in C++: it's OK, they're cheap, and
        # doing them here allows to surface them when the AudioEncoder is
        # instantiated, rather than later when the encoding methods are called.
        if not isinstance(samples, Tensor):
            raise ValueError(
                f"Expected samples to be a Tensor, got {type(samples) = }."
            )
        if samples.ndim == 1:
            # make it 2D and assume 1 channel
            samples = torch.unsqueeze(samples, 0)
        if samples.ndim != 2:
            raise ValueError(f"Expected 1D or 2D samples, got {samples.shape = }.")
        if samples.dtype != torch.float32:
            raise ValueError(f"Expected float32 samples, got {samples.dtype = }.")
        if sample_rate <= 0:
            raise ValueError(f"{sample_rate = } must be > 0.")

        self._samples = samples
        self._sample_rate = sample_rate

    def to_file(
        self,
        dest: str | Path,
        *,
        bit_rate: int | None = None,
        num_channels: int | None = None,
        sample_rate: int | None = None,
    ) -> None:
        """Encode samples into a file.

        Args:
            dest (str or ``pathlib.Path``): The path to the output file, e.g.
                ``audio.mp3``. The extension of the file determines the audio
                format and container.
            bit_rate (int, optional): The output bit rate. Encoders typically
                support a finite set of bit rate values, so ``bit_rate`` will be
                matched to one of those supported values. The default is chosen
                by FFmpeg.
            num_channels (int, optional): The number of channels of the encoded
                output samples. By default, the number of channels of the input
                ``samples`` is used.
            sample_rate (int, optional): The sample rate of the encoded output.
                By default, the sample rate of the input ``samples`` is used.
        """
        encoder = Encoder()
        audio = encoder.add_audio(
            sample_rate=self._sample_rate,
            num_channels=self._samples.shape[0],
            bit_rate=bit_rate,
            out_num_channels=num_channels,
            out_sample_rate=sample_rate,
        )
        with encoder.open_file(dest):
            audio.add_samples(self._samples)

    def to_tensor(
        self,
        format: str,
        *,
        bit_rate: int | None = None,
        num_channels: int | None = None,
        sample_rate: int | None = None,
    ) -> Tensor:
        """Encode samples into raw bytes, as a 1D uint8 Tensor.

        Args:
            format (str): The format of the encoded samples, e.g. "mp3", "wav"
                or "flac".
            bit_rate (int, optional): The output bit rate. Encoders typically
                support a finite set of bit rate values, so ``bit_rate`` will be
                matched to one of those supported values. The default is chosen
                by FFmpeg.
            num_channels (int, optional): The number of channels of the encoded
                output samples. By default, the number of channels of the input
                ``samples`` is used.
            sample_rate (int, optional): The sample rate of the encoded output.
                By default, the sample rate of the input ``samples`` is used.

        Returns:
            Tensor: The raw encoded bytes as 1D uint8 Tensor.
        """
        buf = io.BytesIO()
        encoder = Encoder()
        audio = encoder.add_audio(
            sample_rate=self._sample_rate,
            num_channels=self._samples.shape[0],
            bit_rate=bit_rate,
            out_num_channels=num_channels,
            out_sample_rate=sample_rate,
        )
        with encoder.open_file_like(buf, format=format):
            audio.add_samples(self._samples)
        return torch.frombuffer(buf.getbuffer(), dtype=torch.uint8)

    def to_file_like(
        self,
        file_like,
        format: str,
        *,
        bit_rate: int | None = None,
        num_channels: int | None = None,
        sample_rate: int | None = None,
    ) -> None:
        """Encode samples into a file-like object.

        Args:
            file_like: A file-like object that supports ``write()`` and
                ``seek()`` methods, such as io.BytesIO(), an open file in binary
                write mode, etc. Methods must have the following signature:
                ``write(data: bytes) -> int`` and ``seek(offset: int, whence:
                int = 0) -> int``.
            format (str): The format of the encoded samples, e.g. "mp3", "wav"
                or "flac".
            bit_rate (int, optional): The output bit rate. Encoders typically
                support a finite set of bit rate values, so ``bit_rate`` will be
                matched to one of those supported values. The default is chosen
                by FFmpeg.
            num_channels (int, optional): The number of channels of the encoded
                output samples. By default, the number of channels of the input
                ``samples`` is used.
            sample_rate (int, optional): The sample rate of the encoded output.
                By default, the sample rate of the input ``samples`` is used.
        """
        encoder = Encoder()
        audio = encoder.add_audio(
            sample_rate=self._sample_rate,
            num_channels=self._samples.shape[0],
            bit_rate=bit_rate,
            out_num_channels=num_channels,
            out_sample_rate=sample_rate,
        )
        with encoder.open_file_like(file_like, format=format):
            audio.add_samples(self._samples)
